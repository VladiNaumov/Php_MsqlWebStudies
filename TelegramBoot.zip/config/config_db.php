<?php

//настройки соеденения с сервером БД

    return[
        'dsn' => 'mysql:host=localhost;dbname=u1322686_demo;charset=utf8',
        'user' => 'u1322686_admin',
        'pass' => 'sI3eJ2jV3bhA7j',
        ];